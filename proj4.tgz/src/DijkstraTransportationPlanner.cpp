#include "DijkstraTransportationPlanner.h"
#include "DijkstraPathRouter.h"
#include "BusSystemIndexer.h"
#include "GeographicUtils.h"
#include <vector>
#include <unordered_map>
#include <algorithm>

struct CDijkstraTransportationPlanner::SImplementation{
    std::shared_ptr<SConfiguration> DConfiguration;
    std::vector<std::shared_ptr<CStreetMap::SNode>> DSortedNodes;
    CDijkstraPathRouter DShortestPathRouter;
    CDijkstraPathRouter DFastestPathRouter;
    std::unordered_map<TNodeID, CPathRouter::TVertexID> DShortestNodeToVertex;
    std::unordered_map<TNodeID, CPathRouter::TVertexID> DFastestNodeToVertex;
    CBusSystemIndexer DBusSystemIndexer;

    SImplementation(std::shared_ptr<SConfiguration> config) : DBusSystemIndexer(config->BusSystem()){
        DConfiguration = config;
        //copy every node from the street map into DSortedNodes
        for (size_t Index = 0; Index < DConfiguration->StreetMap()->NodeCount(); Index++){ //loop through every node in street map
            auto Node = DConfiguration->StreetMap()->NodeByIndex(Index); //gets node at the current index from the street map
            DSortedNodes.push_back(Node); //push each node into DSortedNodes vector
        }
        //sort DSortedNodes by node ID
        std::sort(DSortedNodes.begin(), DSortedNodes.end(), [](std::shared_ptr<CStreetMap::SNode> l, std::shared_ptr<CStreetMap::SNode> r) -> bool{
            //std::sort picks two nodes and compares their IDs
            //puts smaller ids first
            return l->ID() < r->ID(); //true means l goes before r, false means r goes before l (swap)
        });
        //add vertices to both routers DShortestPathRouter and DFastestPathRouter
        //also fill in DShortestNodeToVertex and DFastestNodeToVertex to map node IDs to vertex IDs for both routers
        for (size_t Index = 0; Index < DSortedNodes.size(); Index++){
            auto Node = DSortedNodes[Index];
            auto ShortestVertexID = DShortestPathRouter.AddVertex(Node->ID());
            auto FastestVertexID = DFastestPathRouter.AddVertex(Node->ID());
            DShortestNodeToVertex[Node->ID()] = ShortestVertexID;
            DFastestNodeToVertex[Node->ID()] = FastestVertexID;
        }
        // go through every way in the street map
        for (size_t WayIndex = 0; WayIndex < DConfiguration->StreetMap()->WayCount(); WayIndex++){
            auto Way = DConfiguration->StreetMap()->WayByIndex(WayIndex);
            bool IsOneWay = Way->HasAttribute("oneway") && Way->GetAttribute("oneway") == "yes";
    
            for(size_t Index = 1; Index < Way->NodeCount(); Index++){
                auto FirstNodeID = Way->GetNodeID(Index-1);
                auto SecondNodeID = Way->GetNodeID(Index);
                
                auto FirstNode = DConfiguration->StreetMap()->NodeByID(FirstNodeID);
                auto SecondNode = DConfiguration->StreetMap()->NodeByID(SecondNodeID);
                
                auto Distance = SGeographicUtils::HaversineDistanceInMiles(FirstNode->Location(), SecondNode->Location());
                
                auto FirstVertexID = DShortestNodeToVertex[FirstNodeID];
                auto SecondVertexID = DShortestNodeToVertex[SecondNodeID];
                
                DShortestPathRouter.AddEdge(FirstVertexID, SecondVertexID, Distance);
                if(!IsOneWay){
                    DShortestPathRouter.AddEdge(SecondVertexID, FirstVertexID, Distance);
                }
            }
        }
        //Add edges to fastest path router
        for(size_t WayIndex = 0; WayIndex < DConfiguration->StreetMap()->WayCount(); WayIndex++){
            auto Way = DConfiguration->StreetMap()->WayByIndex(WayIndex);
            bool IsOneWay = Way->HasAttribute("oneway") && Way->GetAttribute("oneway") == "yes";
            bool NoBike = Way->HasAttribute("bicycle") && Way->GetAttribute("bicycle") == "no";

            // Parse speed limit
            double SpeedLimit = DConfiguration->DefaultSpeedLimit();
            if(Way->HasAttribute("maxspeed")){
                SpeedLimit = std::stod(Way->GetAttribute("maxspeed"));
            }

            for(size_t Index = 1; Index < Way->NodeCount(); Index++){
                auto FirstNodeID = Way->GetNodeID(Index-1);
                auto SecondNodeID = Way->GetNodeID(Index);
                auto FirstNode = DConfiguration->StreetMap()->NodeByID(FirstNodeID);
                auto SecondNode = DConfiguration->StreetMap()->NodeByID(SecondNodeID);
                auto Distance = SGeographicUtils::HaversineDistanceInMiles(FirstNode->Location(), SecondNode->Location());
                auto FirstVertexID = DFastestNodeToVertex[FirstNodeID];
                auto SecondVertexID = DFastestNodeToVertex[SecondNodeID];

                // Walk edges - always both directions
                double WalkTime = Distance / DConfiguration->WalkSpeed();
                DFastestPathRouter.AddEdge(FirstVertexID, SecondVertexID, WalkTime);
                DFastestPathRouter.AddEdge(SecondVertexID, FirstVertexID, WalkTime);

                // Bike edges - respect oneway, skip if bicycle=no
                if(!NoBike){
                    double BikeTime = Distance / DConfiguration->BikeSpeed();
                    DFastestPathRouter.AddEdge(FirstVertexID, SecondVertexID, BikeTime);
                    if(!IsOneWay){
                        DFastestPathRouter.AddEdge(SecondVertexID, FirstVertexID, BikeTime);
                    }
                }
            }
        }

        // Bus edges - between adjacent bus stops
        for(size_t RouteIndex = 0; RouteIndex < DConfiguration->BusSystem()->RouteCount(); RouteIndex++){
            auto Route = DConfiguration->BusSystem()->RouteByIndex(RouteIndex);
            for(size_t Index = 1; Index < Route->StopCount(); Index++){
                auto PrevStopID = Route->GetStopID(Index-1);
                auto CurrStopID = Route->GetStopID(Index);
                auto PrevStop = DConfiguration->BusSystem()->StopByID(PrevStopID);
                auto CurrStop = DConfiguration->BusSystem()->StopByID(CurrStopID);
                auto PrevNode = DConfiguration->StreetMap()->NodeByID(PrevStop->NodeID());
                auto CurrNode = DConfiguration->StreetMap()->NodeByID(CurrStop->NodeID());
                auto Distance = SGeographicUtils::HaversineDistanceInMiles(PrevNode->Location(), CurrNode->Location());
                double BusStopTimeSec = DConfiguration->BusStopTime() / 3600.0;
                double SpeedLimit = DConfiguration->DefaultSpeedLimit();
                double BusTime = Distance / SpeedLimit + BusStopTimeSec;
                auto PrevVertexID = DFastestNodeToVertex[PrevStop->NodeID()];
                auto CurrVertexID = DFastestNodeToVertex[CurrStop->NodeID()];
                DFastestPathRouter.AddEdge(PrevVertexID, CurrVertexID, BusTime);
            }
        }
    }

    std::size_t NodeCount() const noexcept{
        return DSortedNodes.size();
    }

    std::shared_ptr<CStreetMap::SNode> SortedNodeByIndex(std::size_t index) const noexcept{
        if(index >= DSortedNodes.size()){
            return nullptr;
        }
        return DSortedNodes[index];
    }

    double FindShortestPath(TNodeID src, TNodeID dest, std::vector<TNodeID> &path){
        return CPathRouter::NoPathExists; // stub
    }

    double FindFastestPath(TNodeID src, TNodeID dest, std::vector<TTripStep> &path){
        return CPathRouter::NoPathExists; // stub
    }

    bool GetPathDescription(const std::vector<TTripStep> &path, std::vector<std::string> &desc) const{
        return false; // stub
    }
};

// CDijkstraTransportationPlanner member functions
// Constructor for the Dijkstra Transportation Planner
CDijkstraTransportationPlanner::CDijkstraTransportationPlanner(std::shared_ptr<SConfiguration> config){
    DImplementation = std::make_unique<SImplementation>(config);
}

// Destructor for the Dijkstra Transportation Planner
CDijkstraTransportationPlanner::~CDijkstraTransportationPlanner(){

}

// Returns the number of nodes in the street map
std::size_t CDijkstraTransportationPlanner::NodeCount() const noexcept {
    return DImplementation->NodeCount();
}

// Returns the street map node specified by index if index is less than the
// NodeCount(). nullptr is returned if index is greater than or equal to
// NodeCount(). The nodes are sorted by Node ID.
std::shared_ptr<CStreetMap::SNode> CDijkstraTransportationPlanner::SortedNodeByIndex(std::size_t index) const noexcept{
    return nullptr;
}

// Returns the distance in miles between the src and dest nodes of the
// shortest path if one exists. NoPathExists is returned if no path exists.
// The nodes of the shortest path are filled in the path parameter.
double CDijkstraTransportationPlanner::FindShortestPath(TNodeID src, TNodeID dest, std::vector< TNodeID > &path){
    return CPathRouter::NoPathExists;
}

// Returns the time in hours for the fastest path between the src and dest
// nodes of the if one exists. NoPathExists is returned if no path exists.
// The transportation mode and nodes of the fastest path are filled in the
// path parameter.
double CDijkstraTransportationPlanner::FindFastestPath(TNodeID src, TNodeID dest, std::vector< TTripStep > &path){
    return CPathRouter::NoPathExists;
}

// Returns true if the path description is created. Takes the trip steps path
// and converts it into a human readable set of steps.
bool CDijkstraTransportationPlanner::GetPathDescription(const std::vector< TTripStep > &path, std::vector<
std::string > &desc) const{
    return false;   
}
